// background.js – alarms and budget notifications

importScripts('db.js');

let dbInitialized = false;

async function ensureDB() {
    if (!dbInitialized) {
        await VFADB.initDB();
        dbInitialized = true;
    }
}

async function getCurrentUser() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['currentUser'], (res) => resolve(res.currentUser));
    });
}

// Sync local storage to IndexedDB (legacy – not critical)
chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'local') return;
    await ensureDB();
    const currentUser = await getCurrentUser();
    if (!currentUser) return;
    if (changes.userGoal || changes.totalSpent || changes.spendingHistory) {
        const data = await chrome.storage.local.get(['userGoal', 'totalSpent', 'spendingHistory']);
        await VFADB.setGoal(currentUser, data.userGoal || 0, data.totalSpent || 0);
        const history = data.spendingHistory || [];
        for (const item of history) {
            const existing = await VFADB.getSpendingByUser(currentUser);
            const exists = existing.some(e => e.timestamp === item.timestamp && e.amount === item.amount);
            if (!exists) {
                await VFADB.addSpending(currentUser, item.amount, item.cat, 'auto', item.source || '');
            }
        }
    }
});

// Budget check alarm (every 60 minutes)
chrome.alarms.create('budgetCheck', { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== 'budgetCheck') return;
    await ensureDB();
    const currentUser = await getCurrentUser();
    if (!currentUser) return;
    const goalObj = await VFADB.getGoalObject(currentUser);
    if (!goalObj || goalObj.monthlyGoal === 0) return;
    const spent = goalObj.currentSpent || 0;
    const goal = goalObj.monthlyGoal;
    const percent = (spent / goal) * 100;
    if (percent >= 100) {
        chrome.notifications.create({
            type: 'basic',
            title: '⚠️ Budget Exceeded!',
            message: `You've spent $${spent.toFixed(2)} of your $${goal.toFixed(2)} budget.`,
            priority: 2
        });
    } else if (percent >= 80) {
        chrome.notifications.create({
            type: 'basic',
            title: 'Budget Alert',
            message: `You've used ${percent.toFixed(0)}% of your $${goal.toFixed(2)} budget.`,
            priority: 1
        });
    }
});

chrome.runtime.onInstalled.addListener(async () => {
    await ensureDB();
    const currentUser = await getCurrentUser();
    if (currentUser) {
        const data = await chrome.storage.local.get(['userGoal', 'totalSpent', 'spendingHistory']);
        await VFADB.setGoal(currentUser, data.userGoal || 0, data.totalSpent || 0);
        const history = data.spendingHistory || [];
        for (const item of history) {
            await VFADB.addSpending(currentUser, item.amount, item.cat, 'auto', item.source || '');
        }
    }
});