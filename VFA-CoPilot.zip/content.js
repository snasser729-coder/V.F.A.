// content.js – Absolutely no "Extension context invalidated" errors

let exchangeRate = 89500;
console.log("💰 Using fixed rate: 1 USD = 89,500 LBP");
chrome.storage.local.set({ exchangeRate: exchangeRate });

function isExtensionAlive() {
    try {
        return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
        return false;
    }
}

function safeSet(data) {
    if (!isExtensionAlive()) return;
    try {
        chrome.storage.local.set(data, () => {});
    } catch (e) {}
}

// Safe storage get – always calls callback with {} on failure
function safeGet(keys, callback) {
    if (!isExtensionAlive()) {
        callback({});
        return;
    }
    try {
        chrome.storage.local.get(keys, (result) => {
            try {
                if (chrome.runtime && chrome.runtime.lastError) {
                    callback({});
                } else {
                    callback(result || {});
                }
            } catch (e) {
                callback({});
            }
        });
    } catch (e) {
        callback({});
    }
}

async function updateRate() {
    if (!isExtensionAlive()) return;
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        let rawRate = data.sell_rate !== undefined ? data.sell_rate : data.buy_rate;
        if (rawRate !== undefined) {
            let cleaned = String(rawRate).replace(/,/g, '');
            let newRate = parseFloat(cleaned);
            if (!isNaN(newRate) && newRate > 0) {
                exchangeRate = newRate;
                safeSet({ exchangeRate: exchangeRate });
                console.log("💰 Rate updated:", exchangeRate);
            }
        }
    } catch(e) {
        safeSet({ exchangeRate: exchangeRate });
    }
}
updateRate();

const priceRegex = /(\$|USD|€|EUR|LL|LBP)\s*[\d,]+(?:\.\d{2})?|[\d,]+(?:\.\d{2})?\s*(\$|USD|€|EUR|LL|LBP)/gi;

document.addEventListener('click', (event) => {
    if (!isExtensionAlive()) return;

    let text = event.target.innerText || event.target.textContent || "";
    if (!text && event.target.parentElement)
        text = event.target.parentElement.innerText || "";
    console.log("🖱️ Clicked text:", text.substring(0, 80));

    const match = text.match(priceRegex);
    if (!match) {
        console.log("❌ No price found.");
        return;
    }
    console.log("💰 Price detected:", match[0]);

    safeGet(['userGoal'], async (data) => {
        const goal = parseFloat(data.userGoal) || 0;
        if (goal === 0) {
            console.log("No budget set – ignoring.");
            return;
        }

        let rawPrice = match[0];
        let numeric = parseFloat(rawPrice.replace(/,/g, '').replace(/[^0-9.]/g, ''));
        if (isNaN(numeric)) return;
        let isLBP = rawPrice.toUpperCase().includes("L");
        let usdValue = isLBP ? (numeric / exchangeRate) : numeric;

        const pending = {
            amount: usdValue,
            source: window.location.hostname,
            timestamp: Date.now()
        };
        await safeSet({ pendingPriceDetection: pending, isWaitingForCategoryConfirmation: true });
        console.log("✅ Pending price saved – ask user for confirmation.");
    });
}, true);

console.log("🔵 content.js ready (bulletproof)");