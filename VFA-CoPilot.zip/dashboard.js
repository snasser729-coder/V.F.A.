// dashboard.js – Offline‑ready, no Firestore errors, onboarding, friendly AI errors

const firebaseConfig = {
  apiKey: "AIzaSyDZGSoStBoBVpWnBz382VVdnMJckTdUyd4",
  authDomain: "vfa-co-pilot.firebaseapp.com",
  projectId: "vfa-co-pilot",
  storageBucket: "vfa-co-pilot.firebasestorage.app",
  messagingSenderId: "818442363359",
  appId: "1:818442363359:web:975e6600f5d324bc37246a"
};

let currentUser = null;
let ollamaModel = 'phi3:mini';
let app, auth, firestore;
let isSigningUp = false;

// DOM elements
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const clearBtn = document.getElementById('clear-btn');
const logoutBtn = document.getElementById('logout-btn');
const authScreen = document.getElementById('auth-screen');
const appScreen = document.getElementById('app-screen');
const loginBtn = document.getElementById('login-btn');
const signupBtn = document.getElementById('signup-btn');
const authUsername = document.getElementById('auth-username');
const authPassword = document.getElementById('auth-password');
const authError = document.getElementById('auth-error');
const manualExpenseBtn = document.getElementById('manual-expense-btn');
const manualInputGroup = document.getElementById('manual-input-group');
const manualAmount = document.getElementById('manual-amount');
const manualCategory = document.getElementById('manual-category');
const confirmManualBtn = document.getElementById('confirm-manual-btn');
const settingsBtn = document.getElementById('settings-btn');
const settingsPanel = document.getElementById('settings-panel');
const modelInput = document.getElementById('model-input');
const saveSettingsBtn = document.getElementById('save-settings-btn');

// Helper: online status
function isOnline() {
    return navigator.onLine !== false;
}

function isPasswordStrong(pw) {
    return pw.length >= 8 && /[A-Z]/.test(pw) && /[a-z]/.test(pw) && /[0-9]/.test(pw) && /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(pw);
}

function initFirebase() {
    if (typeof firebase !== 'undefined' && !app) {
        app = firebase.initializeApp(firebaseConfig);
        auth = firebase.auth();
        firestore = firebase.firestore();
        auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
    }
}

// ---------- Per‑user chat storage ----------
async function getUserChatKey() {
    return currentUser ? `chatHistory_${currentUser.uid}` : null;
}
async function loadUserChatHistory() {
    if (!currentUser) return [];
    const key = await getUserChatKey();
    const local = await new Promise(r => chrome.storage.local.get([key], res => r(res[key] || [])));
    if (local.length) return local;
    if (isOnline() && firestore && currentUser) {
        const doc = await firestore.collection('users').doc(currentUser.uid).get();
        const remote = doc.exists ? (doc.data().chatHistory || []) : [];
        if (remote.length) {
            await chrome.storage.local.set({ [key]: remote });
            return remote;
        }
    }
    const welcome = "👋 Hi! I'm VFA, your financial advisor. Set a budget, add expenses, or ask for advice – I'm here to help! 😎📈";
    await saveUserChatHistory([{ text: welcome, sender: 'bot' }]);
    return [{ text: welcome, sender: 'bot' }];
}
async function saveUserChatHistory(history) {
    if (!currentUser) return;
    const key = await getUserChatKey();
    await chrome.storage.local.set({ [key]: history });
    if (isOnline() && firestore && currentUser) {
        await firestore.collection('users').doc(currentUser.uid).set({ chatHistory: history }, { merge: true });
    }
}
async function addChatMessage(text, sender) {
    const history = await loadUserChatHistory();
    history.push({ text, sender });
    await saveUserChatHistory(history);
    renderChat(history);
}
function renderChat(history) {
    chatBox.innerHTML = '';
    history.forEach(msg => {
        const div = document.createElement('div');
        div.className = `msg ${msg.sender}`;
        div.innerText = msg.text;
        chatBox.appendChild(div);
    });
    chatBox.scrollTop = chatBox.scrollHeight;
}

// ---------- UI refresh ----------
async function refreshAllUI() {
    if (!currentUser) return;
    const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
    document.getElementById('goal-value').innerText = `$${userGoal.toFixed(2)}`;
    document.getElementById('spent-value').innerText = `$${totalSpent.toFixed(2)}`;
    const remaining = Math.max(0, userGoal - totalSpent);
    document.getElementById('remaining-value').innerText = `$${remaining.toFixed(2)}`;
    const percent = userGoal > 0 ? (totalSpent / userGoal) * 100 : 0;
    const pb = document.getElementById('progress-bar');
    pb.style.width = `${Math.min(100, percent)}%`;
    pb.style.backgroundColor = percent > 90 ? '#e74c3c' : (percent > 70 ? '#f39c12' : '#2ecc71');

    if (isOnline() && firestore && currentUser) {
        const doc = await firestore.collection('users').doc(currentUser.uid).get();
        renderSpendingLog(doc.exists ? (doc.data().spendingHistory || []) : []);
    }
    const history = await loadUserChatHistory();
    renderChat(history);
    updateRateBadge();
}
function renderSpendingLog(spendingHistory) {
    const logListDiv = document.getElementById('log-list');
    logListDiv.innerHTML = '';
    if (!spendingHistory || spendingHistory.length === 0) {
        logListDiv.innerHTML = '<div style="color:#aaa; text-align:center;">No expenses yet</div>';
        return;
    }
    [...spendingHistory].reverse().forEach((entry, idx) => {
        const originalIndex = spendingHistory.length - 1 - idx;
        const row = document.createElement('div');
        row.className = 'log-entry';
        row.innerHTML = `
            <span class="log-cat">${escapeHtml(entry.category)}</span>
            <span class="log-amount">$${entry.amount.toFixed(2)}</span>
            <button class="delete-btn" data-idx="${originalIndex}">✕</button>
        `;
        logListDiv.appendChild(row);
    });
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const idx = parseInt(btn.dataset.idx);
            const docRef = firestore.collection('users').doc(currentUser.uid);
            const doc = await docRef.get();
            let history = doc.data().spendingHistory || [];
            if (idx >= 0 && idx < history.length) {
                history.splice(idx, 1);
                let newTotal = 0, catTotals = {};
                history.forEach(item => {
                    newTotal += item.amount;
                    catTotals[item.category] = (catTotals[item.category] || 0) + item.amount;
                });
                if (isOnline() && firestore && currentUser) {
                    await docRef.update({ spendingHistory: history, totalSpent: newTotal, categoryTotals: catTotals });
                }
                await chrome.storage.local.set({ totalSpent: newTotal });
                refreshAllUI();
            }
        });
    });
}
function escapeHtml(str) {
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}
async function updateRateBadge() {
    const { exchangeRate = 89500 } = await chrome.storage.local.get(['exchangeRate']);
    document.getElementById('rate-badge').innerText = `1$ ≈ ${exchangeRate.toLocaleString()} LBP`;
}

// ---------- Expense helpers with over‑budget check and offline safety ----------
async function addExpenseToFirestore(amount, category) {
    if (!currentUser) return false;
    const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
    if (totalSpent + amount > userGoal) {
        const remaining = userGoal - totalSpent;
        await addChatMessage(`⚠️ Cannot add $${amount.toFixed(2)} to "${category}". You only have $${remaining.toFixed(2)} left in your budget ($${userGoal.toFixed(2)}).`, 'bot');
        return false;
    }
    // Update local storage first
    const newTotal = totalSpent + amount;
    await chrome.storage.local.set({ totalSpent: newTotal });

    // Update IndexedDB via VFADB (if available) for offline persistence
    if (typeof VFADB !== 'undefined' && VFADB.addSpending) {
        try {
            await VFADB.addSpending(currentUser.uid, amount, category, 'extension', '');
        } catch(e) { console.warn("IndexedDB add failed", e); }
    }

    // Update Firestore only if online
    if (isOnline() && firestore && currentUser) {
        const docRef = firestore.collection('users').doc(currentUser.uid);
        const doc = await docRef.get();
        const data = doc.data() || { spendingHistory: [], totalSpent: 0, userGoal: 0 };
        const newEntry = { amount, category, timestamp: Date.now() };
        const newHistory = [...(data.spendingHistory || []), newEntry];
        let catTotals = data.categoryTotals || {};
        catTotals[category] = (catTotals[category] || 0) + amount;
        await docRef.update({ spendingHistory: newHistory, totalSpent: newTotal, categoryTotals: catTotals });
    }
    refreshAllUI();
    return true;
}
async function syncToLocalStorage() {
    if (!currentUser) return;
    if (isOnline() && firestore && currentUser) {
        const doc = await firestore.collection('users').doc(currentUser.uid).get();
        if (doc.exists) {
            const data = doc.data();
            await chrome.storage.local.set({ userGoal: data.userGoal || 0, totalSpent: data.totalSpent || 0 });
            return;
        }
    }
    // If offline or no Firestore doc, keep existing local values (already set)
}
async function saveToFirestore(goal, spent) {
    if (!currentUser) return;
    await chrome.storage.local.set({ userGoal: goal, totalSpent: spent });
    if (isOnline() && firestore && currentUser) {
        await firestore.collection('users').doc(currentUser.uid).set({ userGoal: goal, totalSpent: spent, updatedAt: Date.now() }, { merge: true });
    }
}

// ---------- Reset Budget ----------
async function resetBudget() {
    if (!currentUser) return;
    await saveToFirestore(0, 0);
    await addChatMessage("🎯 Budget has been reset to $0.", 'bot');
    refreshAllUI();
}

// ---------- Auth ----------
async function signUp(email, password) {
    if (!email || !password) { showAuthError('Email and password required'); return false; }
    if (!isPasswordStrong(password)) {
        showAuthError('Password must have 8+ chars, upper, lower, number, special.');
        return false;
    }
    try {
        isSigningUp = true;
        initFirebase();
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        currentUser = userCredential.user;
        await currentUser.sendEmailVerification();
        if (isOnline() && firestore && currentUser) {
            await firestore.collection('users').doc(currentUser.uid).set({
                userGoal: 0, totalSpent: 0, spendingHistory: [], categoryTotals: {}, chatHistory: [], createdAt: Date.now()
            });
        }
        await auth.signOut();
        currentUser = null;
        showAuthError('Verification email sent. Please verify before logging in.');
        showAuthScreen();
        isSigningUp = false;
        return true;
    } catch (err) {
        isSigningUp = false;
        showAuthError(err.message);
        return false;
    }
}
async function login(email, password) {
    if (!email || !password) { showAuthError('Enter email and password'); return false; }
    try {
        initFirebase();
        const userCredential = await auth.signInWithEmailAndPassword(email, password);
        const user = userCredential.user;
        if (!user.emailVerified) {
            await auth.signOut();
            showAuthError('Please verify your email before logging in.');
            return false;
        }
        currentUser = user;
        await syncToLocalStorage();
        await loadUserChatHistory();
        await checkPendingPriceDetection();
        // Show onboarding message (once)
        const { hasSeenOnboarding } = await chrome.storage.local.get(['hasSeenOnboarding']);
        if (!hasSeenOnboarding) {
            await addChatMessage("🔍 **Tip:** You can click on any price (e.g., $49.99 or 89,500 LBP) on a webpage, and I'll ask if you want to add it as an expense. Try it! 💰", 'bot');
            await chrome.storage.local.set({ hasSeenOnboarding: true });
        }
        showAppScreen();
        refreshAllUI();
        return true;
    } catch (err) {
        showAuthError(err.message);
        return false;
    }
}
async function logout() {
    if (auth) await auth.signOut();
    currentUser = null;
    showAuthScreen();
}

// ---------- Pending price detection with immediate budget warning ----------
async function checkPendingPriceDetection() {
    const { pendingPriceDetection, isWaitingForCategoryConfirmation } = await chrome.storage.local.get(['pendingPriceDetection', 'isWaitingForCategoryConfirmation']);
    if (pendingPriceDetection && isWaitingForCategoryConfirmation) {
        const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
        const newTotal = totalSpent + pendingPriceDetection.amount;
        let warning = '';
        if (newTotal > userGoal) {
            const remaining = userGoal - totalSpent;
            const overBy = newTotal - userGoal;
            warning = ` ⚠️ WARNING: This would exceed your budget by $${overBy.toFixed(2)}! You only have $${remaining.toFixed(2)} left.`;
        }
        await addChatMessage(`📍 Detected: $${pendingPriceDetection.amount.toFixed(2)} from ${pendingPriceDetection.source}.${warning} Do you want to add this as an expense? (reply "yes" or "no")`, 'bot');
        await chrome.storage.local.set({ pendingPriceDetection: null, isWaitingForCategoryConfirmation: false, pendingPrice: pendingPriceDetection.amount, isWaitingForCategory: true });
    }
}

// ---------- Direct command parsing ----------
function parseBudgetCommand(text) {
    const budgetRegex = /(?:set\s+)?(?:my\s+)?budget\s+(?:to\s+)?\$?(\d+(?:\.\d+)?)/i;
    const match = text.match(budgetRegex);
    if (match) return parseFloat(match[1]);
    return null;
}
function parseAddExpenseCommand(text) {
    const addRegex = /add\s+\$?(\d+(?:\.\d+)?)\s+(?:for\s+)?(.+)/i;
    const match = text.match(addRegex);
    if (match) {
        const amount = parseFloat(match[1]);
        let category = match[2].trim();
        if (category.length === 0) category = "uncategorized";
        return { amount, category };
    }
    return null;
}

// ---------- Offline‑first spending history (IndexedDB) ----------
async function getSpendingHistoryOffline() {
    if (!currentUser) return [];
    if (typeof VFADB !== 'undefined' && VFADB.getSpendingByUser) {
        try {
            return await VFADB.getSpendingByUser(currentUser.uid);
        } catch (e) {
            console.warn("IndexedDB read failed", e);
            return [];
        }
    }
    return [];
}

function generateSpendingSummary(spendingHistory, totalSpent, userGoal) {
    if (!spendingHistory || spendingHistory.length === 0) {
        return "📊 You have no recorded expenses yet. Start adding expenses to see your spending summary!";
    }
    const categoryTotals = {};
    spendingHistory.forEach(e => {
        categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
    });
    const sorted = Object.entries(categoryTotals).sort((a,b) => b[1] - a[1]);
    const topCategory = sorted[0];
    const total = totalSpent;
    const remaining = userGoal - total;
    let summary = `📊 **Spending Summary**\n💰 Total spent: $${total.toFixed(2)}\n`;
    if (userGoal > 0) {
        summary += `🎯 Budget: $${userGoal.toFixed(2)} | Remaining: $${remaining.toFixed(2)}\n`;
    }
    summary += `🏷️ Top category: ${topCategory[0]} ($${topCategory[1].toFixed(2)})\n`;
    summary += `📋 All categories:\n`;
    sorted.forEach(([cat, amt]) => {
        summary += `   - ${cat}: $${amt.toFixed(2)}\n`;
    });
    summary += `🕒 Last expenses:\n`;
    spendingHistory.slice(-3).forEach(e => {
        summary += `   - ${e.category}: $${e.amount.toFixed(2)}\n`;
    });
    return summary;
}

function generateAdvice(spendingHistory, totalSpent, userGoal) {
    if (userGoal === 0) {
        return "💡 Set a budget first! Use 'Set my budget to $X' to start tracking.";
    }
    const remaining = userGoal - totalSpent;
    if (remaining < 0) {
        return `⚠️ You have exceeded your budget by $${(-remaining).toFixed(2)}. Consider reducing discretionary spending or adjusting your budget.`;
    }
    if (remaining < userGoal * 0.2) {
        return `🔔 You're close to your budget limit! Only $${remaining.toFixed(2)} left. Try to avoid non‑essential purchases.`;
    }
    if (totalSpent === 0) {
        return `👍 You haven't spent anything yet. Keep up the good work! Remember to track expenses as you go.`;
    }
    const categoryTotals = {};
    spendingHistory.forEach(e => {
        categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
    });
    const top = Object.entries(categoryTotals).sort((a,b)=>b[1]-a[1])[0];
    if (top[1] > totalSpent * 0.5) {
        return `💡 Your largest expense category is "${top[0]}" (${((top[1]/totalSpent)*100).toFixed(0)}% of spending). Could you reduce this? Even a small cut helps!`;
    }
    return `✅ You're on track! Spent $${totalSpent.toFixed(2)} of $${userGoal.toFixed(2)} budget. Keep monitoring your categories.`;
}

// ---------- Strict AI (with user‑friendly error) ----------
async function getFinancialAdvice(userMessage) {
    const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
    const remaining = userGoal - totalSpent;
    let recentSpending = [];
    if (isOnline() && firestore && currentUser) {
        const doc = await firestore.collection('users').doc(currentUser.uid).get();
        recentSpending = doc.exists ? (doc.data().spendingHistory || []) : [];
    } else {
        recentSpending = await getSpendingHistoryOffline();
    }
    let facts = `Budget: $${userGoal}. Spent: $${totalSpent}. Remaining: $${remaining}. `;
    if (recentSpending.length === 0) {
        facts += "No expenses recorded. ";
    } else {
        facts += "Expenses: " + recentSpending.map(e => `${e.category} $${e.amount}`).join(", ") + ". ";
    }
    const systemPrompt = `You are a financial assistant. Answer based ONLY on the data below. Never invent numbers, names, or expenses. If you don't know, say "I don't have that information."

Data: ${facts}`;
    try {
        const response = await fetch('http://127.0.0.1:11434/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: ollamaModel,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                stream: false,
                options: { temperature: 0.3 }
            })
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        let reply = data.message.content.trim();
        const inventedPatterns = [
            /alex\s+harper/i, /name\s+is\s+[a-z]+/i, /budget\s+of\s+\$?\d{3,}/,
            /spent\s+\$?\d+\s+on\s+groceries/i, /rent\s+\$\d+/, /car\s+payment/i,
            /emergency\s+fund/i, /dining\s+out\s+\$?\d+/i
        ];
        for (const pattern of inventedPatterns) {
            if (pattern.test(reply)) {
                reply = "I don't have that information. Please check your actual budget and expenses.";
                break;
            }
        }
        return reply;
    } catch (err) {
        console.error(err);
        return "😔 Sorry, the AI assistant is currently unavailable. Please make sure Ollama is running (set OLLAMA_ORIGINS=* and then ollama serve). You can still track expenses manually!";
    }
}

// ---------- Message handling with category confirmation ----------
async function isWaitingForCategory() {
    return new Promise(r => chrome.storage.local.get(['isWaitingForCategory'], d => r(d.isWaitingForCategory === true)));
}
async function getPendingPrice() {
    return new Promise(r => chrome.storage.local.get(['pendingPrice'], d => r(d.pendingPrice)));
}
async function clearPending() {
    await chrome.storage.local.set({ isWaitingForCategory: false, pendingPrice: null, pendingPriceDetection: null, isWaitingForCategoryConfirmation: false, expectingCategoryName: false });
}
async function handleUserMessage(message) {
    const trimmed = message.trim();
    const waiting = await isWaitingForCategory();
    const pending = await getPendingPrice();

    // Category confirmation flow (price click)
    if (waiting && pending !== null) {
        const lower = trimmed.toLowerCase();
        if (lower === 'yes') {
            await addChatMessage('Great! Please type the category name (e.g., "Food", "Shopping", "Bills").', 'bot');
            await chrome.storage.local.set({ expectingCategoryName: true });
            return;
        } else if (lower === 'no') {
            await addChatMessage('Okay, expense not added. You can add it manually later.', 'bot');
            await clearPending();
            return;
        } else {
            const { expectingCategoryName } = await chrome.storage.local.get(['expectingCategoryName']);
            if (expectingCategoryName) {
                const category = trimmed;
                if (category) {
                    const added = await addExpenseToFirestore(pending, category);
                    if (added) {
                        await addChatMessage(`✅ Added $${pending.toFixed(2)} to "${category}".`, 'bot');
                    }
                    await clearPending();
                    await chrome.storage.local.remove('expectingCategoryName');
                    refreshAllUI();
                } else {
                    await addChatMessage('Please enter a valid category name.', 'bot');
                }
                return;
            } else {
                await addChatMessage('Please answer "yes" or "no" to add this expense.', 'bot');
                return;
            }
        }
    }

    // Direct commands
    const budgetAmount = parseBudgetCommand(trimmed);
    if (budgetAmount !== null) {
        await saveToFirestore(budgetAmount, 0);
        await addChatMessage(`🎯 Budget goal set to $${budgetAmount.toFixed(2)}.`, 'bot');
        refreshAllUI();
        return;
    }

    const expense = parseAddExpenseCommand(trimmed);
    if (expense !== null) {
        const added = await addExpenseToFirestore(expense.amount, expense.category);
        if (added) {
            await addChatMessage(`✅ Added $${expense.amount.toFixed(2)} to "${expense.category}".`, 'bot');
        }
        refreshAllUI();
        return;
    }

    const numberMatch = trimmed.match(/^\d+(?:\.\d+)?$/);
    if (numberMatch) {
        const amount = parseFloat(numberMatch[0]);
        await saveToFirestore(amount, 0);
        await addChatMessage(`🎯 Budget goal set to $${amount.toFixed(2)}.`, 'bot');
        refreshAllUI();
        return;
    }

    // AI chat
    await addChatMessage("💭 VFA is thinking...", 'bot');
    const aiReply = await getFinancialAdvice(trimmed);
    if (aiReply) {
        await addChatMessage(aiReply, 'bot');
    }
}

// ---------- Buttons ----------
document.getElementById('suggest-set-budget').onclick = () => {
    userInput.value = "Set my budget to $";
    userInput.focus();
};

document.getElementById('suggest-summary').onclick = async () => {
    const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
    let spendingHistory = [];
    if (isOnline() && firestore && currentUser) {
        try {
            const doc = await firestore.collection('users').doc(currentUser.uid).get();
            spendingHistory = doc.exists ? (doc.data().spendingHistory || []) : [];
        } catch (err) {
            console.warn("Firestore offline, falling back to IndexedDB");
            spendingHistory = await getSpendingHistoryOffline();
        }
    } else {
        spendingHistory = await getSpendingHistoryOffline();
    }
    const summary = generateSpendingSummary(spendingHistory, totalSpent, userGoal);
    await addChatMessage(summary, 'bot');
    userInput.value = "";
};

document.getElementById('suggest-advice').onclick = async () => {
    const { userGoal = 0, totalSpent = 0 } = await chrome.storage.local.get(['userGoal', 'totalSpent']);
    let spendingHistory = [];
    if (isOnline() && firestore && currentUser) {
        try {
            const doc = await firestore.collection('users').doc(currentUser.uid).get();
            spendingHistory = doc.exists ? (doc.data().spendingHistory || []) : [];
        } catch (err) {
            console.warn("Firestore offline, falling back to IndexedDB");
            spendingHistory = await getSpendingHistoryOffline();
        }
    } else {
        spendingHistory = await getSpendingHistoryOffline();
    }
    const advice = generateAdvice(spendingHistory, totalSpent, userGoal);
    await addChatMessage(advice, 'bot');
    userInput.value = "";
};

document.getElementById('refresh-rate-btn').addEventListener('click', async () => {
    await chrome.storage.local.set({ exchangeRate: 89500 });
    updateRateBadge();
    addChatMessage("💰 Exchange rate manually set to 1$ = 89,500 LBP", 'bot');
});

function resetSession() {
    saveUserChatHistory([{ text: "🧹 Session reset. Chat cleared. Your budget and expenses remain unchanged.", sender: 'bot' }]);
    refreshAllUI();
}

// ---------- Initialization ----------
document.addEventListener('DOMContentLoaded', async () => {
    initFirebase();

    const savedModel = await new Promise(r => chrome.storage.local.get(['ollamaModel'], r));
    if (savedModel.ollamaModel) ollamaModel = savedModel.ollamaModel;
    modelInput.value = ollamaModel;

    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-overlay';
    loadingDiv.style.cssText = 'position:absolute; top:0; left:0; right:0; bottom:0; background:#0a0c10; display:flex; justify-content:center; align-items:center; z-index:300; color:white; font-size:18px;';
    loadingDiv.innerText = 'Loading...';
    document.body.appendChild(loadingDiv);
    authScreen.style.display = 'none';
    appScreen.style.display = 'none';

    auth.onAuthStateChanged(async (user) => {
        if (isSigningUp) return;
        if (user && user.emailVerified) {
            currentUser = user;
            await syncToLocalStorage();
            await loadUserChatHistory();
            await checkPendingPriceDetection();
            loadingDiv.remove();
            showAppScreen();
            refreshAllUI();
        } else if (user && !user.emailVerified) {
            await auth.signOut();
            loadingDiv.remove();
            showAuthScreen();
            showAuthError('Please verify your email before logging in.');
        } else {
            loadingDiv.remove();
            showAuthScreen();
        }
    });

    loginBtn.onclick = async () => {
        const email = authUsername.value;
        const pw = authPassword.value;
        await login(email, pw);
    };
    signupBtn.onclick = async () => {
        const email = authUsername.value;
        const pw = authPassword.value;
        await signUp(email, pw);
    };
    logoutBtn.onclick = () => logout();
    sendBtn.onclick = async () => {
        const text = userInput.value.trim();
        if (!text) return;
        userInput.value = '';
        await addChatMessage(text, 'user');
        await handleUserMessage(text);
    };
    userInput.onkeypress = (e) => { if (e.key === 'Enter') sendBtn.click(); };
    clearBtn.onclick = resetSession;
    manualExpenseBtn.addEventListener('click', () => {
        manualInputGroup.style.display = manualInputGroup.style.display === 'none' ? 'flex' : 'none';
    });
    confirmManualBtn.addEventListener('click', async () => {
        const amount = parseFloat(manualAmount.value);
        const category = manualCategory.value.trim();
        if (isNaN(amount) || amount <= 0 || !category) {
            await addChatMessage('Please enter a valid amount and category.', 'bot');
            return;
        }
        const added = await addExpenseToFirestore(amount, category);
        if (added) {
            await addChatMessage(`✅ Added $${amount.toFixed(2)} to "${category}".`, 'bot');
        }
        refreshAllUI();
        manualAmount.value = '';
        manualCategory.value = '';
        manualInputGroup.style.display = 'none';
    });
    settingsBtn.onclick = () => {
        settingsPanel.style.display = settingsPanel.style.display === 'none' ? 'block' : 'none';
    };
    saveSettingsBtn.onclick = async () => {
        const model = modelInput.value.trim();
        if (model) {
            ollamaModel = model;
            await new Promise(r => chrome.storage.local.set({ ollamaModel: model }, r));
            await addChatMessage(`✅ Ollama model set to "${model}".`, 'bot');
            settingsPanel.style.display = 'none';
        }
    };
    document.getElementById('reset-budget-btn').addEventListener('click', resetBudget);

    // Real‑time storage listener
    chrome.storage.onChanged.addListener(async (changes, area) => {
        if (area === 'local') {
            if (changes.pendingPriceDetection && currentUser) {
                await checkPendingPriceDetection();
            }
            if (changes.chatHistory || changes.pendingPrice || changes.isWaitingForCategory) {
                refreshAllUI();
            }
        }
    });

    if (Notification.permission === 'default') Notification.requestPermission();

    document.querySelectorAll('.password-toggle').forEach(toggle => {
        toggle.addEventListener('click', () => {
            const targetId = toggle.getAttribute('data-target');
            const input = document.getElementById(targetId);
            if (input) {
                if (input.type === 'password') {
                    input.type = 'text';
                    toggle.textContent = '🙈';
                } else {
                    input.type = 'password';
                    toggle.textContent = '👁️';
                }
            }
        });
    });
});

function showAuthError(msg) {
    authError.innerText = msg;
    setTimeout(() => authError.innerText = '', 3000);
}
function showAppScreen() { authScreen.style.display = 'none'; appScreen.style.display = 'flex'; logoutBtn.style.display = 'block'; }
function showAuthScreen() { authScreen.style.display = 'flex'; appScreen.style.display = 'none'; logoutBtn.style.display = 'none'; }