// db.js – IndexedDB wrapper (no ES modules)

(function(global) {
    const DB_NAME = 'vfa_db';
    const DB_VERSION = 2;
    const STORES = {
        USERS: 'users',
        SPENDING: 'spending',
        GOALS: 'goals',
        SETTINGS: 'settings'
    };

    let db = null;

    async function initDB() {
        if (db) return db;
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                db = request.result;
                resolve(db);
            };
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(STORES.USERS)) {
                    const userStore = db.createObjectStore(STORES.USERS, { keyPath: 'id' });
                    userStore.createIndex('by_username', 'id', { unique: true });
                }
                if (!db.objectStoreNames.contains(STORES.SPENDING)) {
                    const spendingStore = db.createObjectStore(STORES.SPENDING, { keyPath: 'id', autoIncrement: true });
                    spendingStore.createIndex('by_user', 'userId');
                    spendingStore.createIndex('by_timestamp', 'timestamp');
                }
                if (!db.objectStoreNames.contains(STORES.GOALS)) {
                    db.createObjectStore(STORES.GOALS, { keyPath: 'userId' });
                }
                if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
                    db.createObjectStore(STORES.SETTINGS, { keyPath: 'userId' });
                }
            };
        });
    }

    async function getStore(storeName, mode = 'readonly') {
        if (!db) await initDB();
        const tx = db.transaction(storeName, mode);
        return tx.objectStore(storeName);
    }

    async function addItem(storeName, item) {
        const store = await getStore(storeName, 'readwrite');
        return new Promise((resolve, reject) => {
            const req = store.add(item);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async function getItem(storeName, key) {
        const store = await getStore(storeName, 'readonly');
        return new Promise((resolve, reject) => {
            const req = store.get(key);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async function getAllItems(storeName, indexName = null, keyRange = null) {
        const store = await getStore(storeName, 'readonly');
        let source = store;
        if (indexName) source = store.index(indexName);
        return new Promise((resolve, reject) => {
            const req = keyRange ? source.getAll(keyRange) : source.getAll();
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async function updateItem(storeName, item) {
        const store = await getStore(storeName, 'readwrite');
        return new Promise((resolve, reject) => {
            const req = store.put(item);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async function deleteItem(storeName, key) {
        const store = await getStore(storeName, 'readwrite');
        return new Promise((resolve, reject) => {
            const req = store.delete(key);
            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);
        });
    }

    async function getSpendingByUser(userId, limit = 100) {
        const items = await getAllItems(STORES.SPENDING, 'by_user', IDBKeyRange.only(userId));
        return items.sort((a,b) => b.timestamp - a.timestamp).slice(0, limit);
    }

    async function getGoalObject(userId) {
        return await getItem(STORES.GOALS, userId);
    }

    async function setGoal(userId, monthlyGoal, currentSpent = 0) {
        await updateItem(STORES.GOALS, { userId, monthlyGoal, currentSpent, updatedAt: Date.now() });
    }

    async function addSpending(userId, amount, category, source = 'manual', note = '') {
        const newItem = {
            userId,
            amount,
            category,
            source,
            note,
            timestamp: Date.now()
        };
        const id = await addItem(STORES.SPENDING, newItem);
        const goal = await getItem(STORES.GOALS, userId);
        if (goal) {
            goal.currentSpent = (goal.currentSpent || 0) + amount;
            await updateItem(STORES.GOALS, goal);
        }
        return id;
    }

    async function updateSpendingTotal(userId) {
        const items = await getSpendingByUser(userId);
        const newTotal = items.reduce((sum, i) => sum + i.amount, 0);
        const goal = await getItem(STORES.GOALS, userId);
        if (goal) {
            goal.currentSpent = newTotal;
            await updateItem(STORES.GOALS, goal);
        }
        return newTotal;
    }

    global.VFADB = {
        initDB,
        addItem,
        getItem,
        getAllItems,
        updateItem,
        deleteItem,
        getSpendingByUser,
        getGoalObject,
        setGoal,
        addSpending,
        updateSpendingTotal
    };
})(typeof self !== 'undefined' ? self : window);